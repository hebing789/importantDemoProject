//
//  BackView.h
//  123cw
//
//  Created by 曹文文 on 16/9/15.
//  Copyright © 2016年 com.joey. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface BackView : UIView

@property (nonatomic, strong) UILabel *footerLabel;

@end
