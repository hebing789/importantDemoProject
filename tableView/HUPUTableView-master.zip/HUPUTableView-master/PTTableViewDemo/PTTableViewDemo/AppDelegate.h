//
//  AppDelegate.h
//  PTTableViewDemo
//
//  Created by joey on 16/10/29.
//  Copyright © 2016年 com.joey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

