//
//  ViewController.h
//  FMGodTableView
//
//  Created by dangfm on 16/3/14.
//  Copyright © 2016年 dangfm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMGodTableView.h"

@interface ViewController : UIViewController
@property (nonatomic,assign) float CellLastScrollX; // 最后的cell的移动距离

@end

