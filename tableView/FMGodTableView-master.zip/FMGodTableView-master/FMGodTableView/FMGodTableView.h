//
//  FMGodTableView.h
//  FMGodTableView
//
//  Created by dangfm on 16/3/14.
//  Copyright © 2016年 dangfm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMGodTableViewCell.h"

@interface FMGodTableView : UITableView

@end
