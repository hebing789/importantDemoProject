//
//  RootViewController.h
//  MultiSelectView
//
//  Created by Jakey on 15/3/10.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MultiSelectView.h"
@interface RootViewController : UIViewController
@property (weak, nonatomic) IBOutlet MultiSelectView *multiSelect;

@end
