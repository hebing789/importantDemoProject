//
//  AppDelegate.h
//  DraggingSort
//
//  Created by HelloYeah on 16/11/16.
//  Copyright © 2016年 YL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

