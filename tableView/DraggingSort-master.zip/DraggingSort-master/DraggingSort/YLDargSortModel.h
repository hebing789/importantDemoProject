//
//   YLModel.h
//   
//
//  Created by HelloYeah on 2016/12/2.
//  Copyright © 2016年 YeLiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YLDargSortModel : NSObject

@property (nonatomic,copy) NSString * name;
@property (nonatomic,assign) BOOL  selectedFlag;

@end
