//
//  main.m
//  tableviewCellSelect
//
//  Created by 刘光军 on 15/11/15.
//  Copyright © 2015年 刘光军. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
