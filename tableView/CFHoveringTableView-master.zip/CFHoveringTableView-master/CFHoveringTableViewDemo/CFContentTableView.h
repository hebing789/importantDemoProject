//
//  CFContentTableView.h
//  CFHoveringTableViewDemo
//
//  Created by 于传峰 on 16/9/10.
//  Copyright © 2016年 于传峰. All rights reserved.
//  Abstract:<#necessory condition: include main function and matters needing attention#>

#import <UIKit/UIKit.h>

#define TitleHeight 45

//@protocol CFContentScrollDelegate <NSObject>
//
//@required
//- (void)cf_ContentScrollContentOffset:(CGPoint)contentOffset scrollView:(UIScrollView *)scrollView;
//
//@end

@interface CFContentTableView : UITableView

@end
