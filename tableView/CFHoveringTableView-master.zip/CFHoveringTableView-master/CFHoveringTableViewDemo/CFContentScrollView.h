//
//  CFContentScrollView.h
//  CFHoveringTableViewDemo
//
//  Created by 于传峰 on 2016/10/10.
//  Copyright © 2016年 于传峰. All rights reserved.
//

#import <UIKit/UIKit.h>


#define HeadViewHeight 200

@interface CFContentScrollView : UIScrollView
@property (nonatomic, assign) CGPoint offset;
@end
