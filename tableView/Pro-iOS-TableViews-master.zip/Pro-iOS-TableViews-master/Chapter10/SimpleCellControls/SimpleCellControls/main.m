//
//  main.m
//  SimpleCellControls
//
//  Created by Tim Duckett on 03/01/2012.
//  Copyright (c) 2012 Charismatic Megafauna Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SCCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SCCAppDelegate class]));
    }
}
