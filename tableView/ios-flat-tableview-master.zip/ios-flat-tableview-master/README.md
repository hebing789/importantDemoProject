ios-flat-tableview
==================

Grouped UITableView with custom border radius

![UITableView](https://dl.dropboxusercontent.com/u/99114459/ios-flat-tableview.gif)

