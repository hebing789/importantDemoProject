//
//  main.m
//  LRLayerSuperposition
//
//  Created by 卢然 on 16/7/17.
//  Copyright © 2016年 scorpio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
