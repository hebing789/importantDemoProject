# WZBLinkageTableView
一个仿 饿了么 选餐时的两个tableView联动效果

详解在这:http://www.jianshu.com/p/dfb73aa08602

实现效果如下：

 ![image](https://github.com/WZBbiao/WZBLinkageTableView/blob/master/WZBLinkageTableView.gif?raw=true)


 您还可以加入我们的群，大家庭期待您的加入！
 
 ![image](https://raw.githubusercontent.com/WZBbiao/WZBSwitch/master/IMG_1850.JPG)
