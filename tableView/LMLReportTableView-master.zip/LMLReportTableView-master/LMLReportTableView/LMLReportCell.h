//
//  LMLReportCell.h
//  Cell的折叠
//
//  Created by 优谱德 on 16/7/9.
//  Copyright © 2016年 董诗磊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMLReportCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
