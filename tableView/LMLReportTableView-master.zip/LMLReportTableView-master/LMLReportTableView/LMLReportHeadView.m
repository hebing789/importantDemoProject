//
//  LMLReportHeadView.m
//  Cell的折叠
//
//  Created by 优谱德 on 16/7/9.
//  Copyright © 2016年 董诗磊. All rights reserved.
//

#import "LMLReportHeadView.h"

@implementation LMLReportHeadView

- (void)awakeFromNib {

    [self initUI];
}

#pragma mark - init 

- (void)initUI {

    self.checkImage.hidden = YES;
}



@end
