//
//  IndexTabelView.h
//  scrollviews
//
//  Created by gaowei on 2016/10/20.
//  Copyright © 2016年 xes. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MJRefresh.h"

@interface IndexTabelView : UITableView

-(void)setScrollViewContentOffSet:(CGPoint)point;

@end
