//
//  JWTableViewController.h
//  JWCutWeightForVC
//
//  Created by 微凉 on 16/4/26.
//  Copyright © 2016年 微凉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JWTableViewController : UITableViewController
@property(copy,nonatomic)NSArray *models;

@end
